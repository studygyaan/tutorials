Find this Tutorial on https://studygyaan.com/django/django-basic-skeleton-project
