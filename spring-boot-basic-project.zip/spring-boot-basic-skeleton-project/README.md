Find this tutorial on https://studygyaan.com/spring-boot/spring-boot-basic-skeleton-project
